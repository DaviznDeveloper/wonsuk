package kr.co.davizn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.davizn.model.EmpDto;
import kr.co.davizn.service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	private EmpService empservice;
	
	@RequestMapping()
	public String insert(EmpDto dto){
		empservice.insert(dto);
		return "emp.empList";
	}
	
	@RequestMapping()
	public String delete(int empno){	
		empservice.delete(empno);
		return "emp.empList";
	}
	
	@RequestMapping()
	public String edit(EmpDto dto){
		empservice.edit(dto);
		return "emp.empList";
	}
	
	@RequestMapping()
	public String getEmps(EmpDto dto){
		empservice.getEmps(dto);
		return "emp.empList";
	}
	
	@RequestMapping()
	public String getEmp(EmpDto dto){
		empservice.getEmp(dto);
		return "emp.empList";
	}
}
