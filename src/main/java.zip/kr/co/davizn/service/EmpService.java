package kr.co.davizn.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import kr.co.davizn.model.EmpDao;
import kr.co.davizn.model.EmpDto;

public class EmpService {
	
	@Autowired
	private SqlSession sqlsession;
	
	public String insert(EmpDto dto){
		EmpDao empdao= sqlsession.getMapper(EmpDao.class);
		empdao.insertEmp(dto);
		return "emp.list";
	}
	public String delete(int empno){	
		EmpDao empdao= sqlsession.getMapper(EmpDao.class);
		empdao.deleteEmp(empno);
		return "emp.list";
	}
	public String edit(EmpDto dto){
		EmpDao empdao= sqlsession.getMapper(EmpDao.class);
		empdao.updateEmp(dto);
		return "emp.list";
	}
	public String getEmps(EmpDto dto){
		EmpDao empdao= sqlsession.getMapper(EmpDao.class);
		empdao.getEmpList(dto);
		return "emp.list";
	}
	public String getEmp(EmpDto dto){
		EmpDao empdao= sqlsession.getMapper(EmpDao.class);
		empdao.getEmp(dto);
		return "emp.list";
	}
}
