package kr.co.davizn.model;

import java.util.List;

public interface EmpDao {
	public int insertEmp(EmpDto dto);
	public int deleteEmp(int empno);
	public int updateEmp(EmpDto dto);
	public EmpDto getEmp(EmpDto dto);
	public List<EmpDto> getEmpList(EmpDto dto);
}
